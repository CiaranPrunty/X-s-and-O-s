﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace PruntyCiaranProject
{

    public sealed partial class MainPage : Page
    {
        //variable

        int playerMove;

        public MainPage()
        {
            this.InitializeComponent();
        }

        
        // first move is player 1 with O's
        private void onClickOne(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block1.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block1.Content = "X";
                playerMove-- ;
            }

            Block1.IsEnabled = false;

            result();
        }

        private void onClickTwo(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block2.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block2.Content = "X";
                playerMove-- ;
            }

            Block2.IsEnabled = false;

            result();
        }

        private void onClickThree(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block3.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block3.Content = "X";
                playerMove-- ;
            }

            Block3.IsEnabled = false;

            result();
        }

        private void onClickFour(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block4.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block4.Content = "X";
                playerMove-- ;
            }

            Block4.IsEnabled = false;

            result();
        }

        private void onClickFive(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block5.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block5.Content = "X";
                playerMove-- ;
            }

            Block5.IsEnabled = false;

            result();
        }

        private void onClickSix(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block6.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block6.Content = "X";
                playerMove-- ;
            }

            Block6.IsEnabled = false;

            result();
        }

        private void onClickSeven(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block7.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block7.Content = "X";
                playerMove-- ;
            }

            Block7.IsEnabled = false;

            result();
        }

        private void onClickEight(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block8.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block8.Content = "X";
                playerMove-- ;
            }

            Block8.IsEnabled = false;

            result();
        }

        private void onClickNine(object sender, RoutedEventArgs e)
        {
            if (playerMove == 0)
            {
                Block9.Content = "O";
                playerMove++ ;
            }
            else if (playerMove == 1)
            {
                Block9.Content = "X";
                playerMove-- ;
            }
            Block9.IsEnabled = false;

            result();
        }

        //newGame restarts game back to begining 
        private void newGame(object sender, RoutedEventArgs e)
        {
            Block1.Content = "";
            Block1.IsEnabled = true;
            Block2.Content = "";
            Block2.IsEnabled = true;
            Block3.Content = "";
            Block3.IsEnabled = true;
            Block4.Content = "";
            Block4.IsEnabled = true;
            Block5.Content = "";
            Block5.IsEnabled = true;
            Block6.Content = "";
            Block6.IsEnabled = true;
            Block7.Content = "";
            Block7.IsEnabled = true;
            Block8.Content = "";
            Block8.IsEnabled = true;
            Block9.Content = "";
            Block9.IsEnabled = true;
            resultText.Text = "";
        }

        //result is called in all onClicks to check if someone's the winner 

        void result()
        {
            //if statement to check if O's wins
            if (Block1.Content == "O" && Block2.Content == "O" && Block3.Content == "O"
               || Block1.Content == "O" && Block5.Content == "O" && Block9.Content == "O"
               || Block1.Content == "O" && Block4.Content == "O" && Block7.Content == "O"
               || Block2.Content == "O" && Block5.Content == "O" && Block8.Content == "O"
               || Block3.Content == "O" && Block6.Content == "O" && Block9.Content == "O"
               || Block7.Content == "O" && Block8.Content == "O" && Block9.Content == "O"
               || Block4.Content == "O" && Block5.Content == "O" && Block6.Content == "O"
               || Block3.Content == "O" && Block5.Content == "O" && Block7.Content == "O")
            {
                resultText.Text = "Player O is Victorious";

                Block1.IsEnabled = false;
                Block2.IsEnabled = false;
                Block3.IsEnabled = false;
                Block4.IsEnabled = false;
                Block5.IsEnabled = false;
                Block6.IsEnabled = false;
                Block7.IsEnabled = false;
                Block8.IsEnabled = false;
                Block9.IsEnabled = false;
            }

            //if statement to check if X's wins
            if (Block1.Content == "X" && Block2.Content == "X" && Block3.Content == "X"
                || Block1.Content == "X" && Block5.Content == "X" && Block9.Content == "X"
                || Block1.Content == "X" && Block4.Content == "X" && Block7.Content == "X"
                || Block2.Content == "X" && Block5.Content == "X" && Block8.Content == "X"
                || Block3.Content == "X" && Block6.Content == "X" && Block9.Content == "X"
                || Block7.Content == "X" && Block8.Content == "X" && Block9.Content == "X"
                || Block4.Content == "X" && Block5.Content == "X" && Block6.Content == "X"
                || Block3.Content == "X" && Block5.Content == "X" && Block7.Content == "X")
            {
                resultText.Text = "Player X is Victorious";

                Block1.IsEnabled = false;
                Block2.IsEnabled = false;
                Block3.IsEnabled = false;
                Block4.IsEnabled = false;
                Block5.IsEnabled = false;
                Block6.IsEnabled = false;
                Block7.IsEnabled = false;
                Block8.IsEnabled = false;
                Block9.IsEnabled = false;
            }

            
        }
    }
}